export const AUTH_IS_PUBLIC_KEY = 'isPublic';
